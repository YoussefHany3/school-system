<?php

echo "This is homework assign page!";

?>