<?php

    if(!isset($_COOKIE["status"])){
        header("location: ../views/login.php");
    }
?>